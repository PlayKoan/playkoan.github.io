KOAN, the terminal game

You need Python 3.11 or newer. Nothing to install. In this folder:

    python3 game.py           what this is
    python3 game.py help      how to play (one page)
    python3 game.py new       a new puzzle

If python3 is not found, type python instead. The game keeps its save in a folder
named .save here, or in the folder named by the GAME_HOME environment variable.
Honor code: play only through the commands; do not read the engine or the save.

Directed by Catbunlore. Made with Claude. MIT licence: see LICENSE.
